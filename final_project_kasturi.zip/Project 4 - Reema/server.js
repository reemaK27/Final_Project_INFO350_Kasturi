const express = require("express");
const app = express();

app.use(express.json());

app.use((req, res, next) => {
    console.log(req.method, req.url);
    next();
});

const greeting = process.env.GREETING || "Hello from your API";

let items = [
    { name: "Sample Item 1" },
    { name: "Sample Item 2" }
];

app.get("/api/items", (req, res) => {
    res.json(items);
});

app.post("/api/items", (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ error: "Name is required" });
    }
    const newItem = { name };
    items.push(newItem);
    res.status(201).json(newItem);
});

app.get("/api/message", (req, res) => {
    res.json({ message: greeting });
});

app.listen(process.env.PORT || 3000);
