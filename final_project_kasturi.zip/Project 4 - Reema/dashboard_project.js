const API_BASE = "https://your-backend-url.onrender.com";

document.getElementById("userForm").onsubmit = function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const color = document.getElementById("color").value.trim();
    const error = document.getElementById("formError");

    if (!name || !email || !color) {
        error.textContent = "All fields are required.";
        return;
    }

    error.textContent = "";

    document.getElementById("displayName").textContent = name;
    document.getElementById("displayEmail").textContent = email;
    document.getElementById("displayColor").textContent = color;
};

const todoInput = document.getElementById("todoInput");
const todoList = document.getElementById("todoList");
const jsonOutput = document.getElementById("jsonOutput");

document.getElementById("addTodo").onclick = () => {
    const task = todoInput.value.trim();
    if (!task) return;

    const li = document.createElement("li");
    li.textContent = task;
    todoList.appendChild(li);

    todoInput.value = "";
    updateJSON();
};

document.getElementById("sortAZ").onclick = () => sortList(true);
document.getElementById("sortZA").onclick = () => sortList(false);

function sortList(ascending) {
    const items = [...todoList.children];
    items.sort((a, b) =>
        ascending
            ? a.textContent.localeCompare(b.textContent)
            : b.textContent.localeCompare(a.textContent)
    );

    todoList.innerHTML = "";
    items.forEach(i => todoList.appendChild(i));
    updateJSON();
}

function updateJSON() {
    const tasks = [...todoList.children].map(li => li.textContent);
    jsonOutput.textContent = JSON.stringify(tasks);
}

const itemDisplay = document.getElementById("item-display");
const loadItemsBtn = document.getElementById("loadItems");
const clearItemsBtn = document.getElementById("clearItems");

const showLoading = () => {
    itemDisplay.innerHTML = `<p style="color:indigo;">Loading...</p>`;
};

const showError = () => {
    itemDisplay.innerHTML = `<p style="color:red;">Failed to load items.</p>`;
};

async function loadItems() {
    showLoading();

    try {
        const res = await fetch(`${API_BASE}/api/items`);
        const data = await res.json();

        if (!Array.isArray(data) || data.length === 0) {
            itemDisplay.innerHTML = `<p style="color:indigo;">No items found.</p>`;
            return;
        }

        itemDisplay.innerHTML = data
            .map(item => `<li>${item.name}</li>`)
            .join("");
    } catch (err) {
        showError();
    }
}

loadItemsBtn.onclick = loadItems;
clearItemsBtn.onclick = () => (itemDisplay.innerHTML = "");
